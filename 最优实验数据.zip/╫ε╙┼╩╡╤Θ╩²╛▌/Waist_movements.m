%% preallocation of resources
n = 2;                      %number of channels
fs = 200;                %sampling frequency
T = 1 / fs;               %sampling period


%% MVC calculation

MVC_Lwaist =  492;
MVC_Rwaist = 486;

MVC_waist = [MVC_Rwaist MVC_Lwaist];



%% Movement 1: Bent knees hold abdomen

BL = length(Bentkneesholdabdomen);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Btime, Bentkneesholdabdomen(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Waist ');
     else
         title(' Left Waist ');
     end
end

sgtitle(' "Bent knees hold abdomen" Waist  EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:BL
    Bentkneesholdabdomen_MAV(k, i) = sum( Bentkneesholdabdomen(k-99:k, i) ) / window;
    end
end

Bentkneesholdabdomen_MAV(all(Bentkneesholdabdomen_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Bindex = length(Bentkneesholdabdomen_MAV);

avg_MAV_Bentkneesholdabdomen = [sum( Bentkneesholdabdomen_MAV(1:Bindex, 1) ) / 60 sum( Bentkneesholdabdomen_MAV(1:Bindex, 2) ) / 60];



%% Normalized

for i = 1:n
    Bentkneesholdabdomen_MAV_Norm(:, i) = (avg_MAV_Bentkneesholdabdomen(:,i)./MVC_waist(1, i)).*100;
end






%% Movement 2: Crunches

CL = length(Crunches);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Ctime, Crunches(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Waist ');
     else
         title(' Left Waist ');
     end
end

sgtitle(' "Crunches" Waist  EMG signal ');
hold off



%% MAV calculation


for i = 1:n
    for k = 100:window:CL
    Crunches_MAV(k, i) = sum( Crunches(k-99:k, i) ) / window;
    end
end

Crunches_MAV(all(Crunches_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Cindex = length(Crunches_MAV);

avg_MAV_Crunches = [sum( Crunches_MAV(1:Cindex, 1) ) / 57 sum( Crunches_MAV(1:Cindex, 2) ) / 57];



%% Normalized

for i = 1:n
    Crunches_MAV_Norm(:, i) = (avg_MAV_Crunches(:,i)./MVC_waist(1, i)).*100;
end





%% Movement 3: Lying leg raises

LL = length(Lyinglegraises);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Ltime, Lyinglegraises(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Waist ');
     else
         title(' Left Waist ');
     end
end

sgtitle(' "Lying leg raises" Waist  EMG signal ');
hold off



%% MAV calculation


for i = 1:n
    for k = 100:window:LL
    Lyinglegraises_MAV(k, i) = sum( Lyinglegraises(k-99:k, i) ) / window;
    end
end

Lyinglegraises_MAV(all(Lyinglegraises_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix


Lindex = length(Lyinglegraises_MAV);

avg_MAV_Lyinglegraises = [sum( Lyinglegraises_MAV(1:Lindex, 1) ) / 60 sum( Lyinglegraises_MAV(1:Lindex, 2) ) / 60];



%% Normalized

for i = 1:n
    Lyinglegraises_MAV_Norm(:, i) = (avg_MAV_Lyinglegraises(:,i)./MVC_waist(1, i)).*100;
end






%% Movement 4: Air_cycling

AL = length(Aircycling);



%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Atime, Aircycling(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Waist ');
     else
         title(' Left Waist ');
     end
end

sgtitle(' "Aircycling" Waist  EMG signal ');
hold off



%% MAV calculation


for i = 1:n
    for k = 100:window:AL
   Aircycling_MAV(k, i) = sum( Aircycling(k-99:k, i) ) / window;
    end
end

Aircycling_MAV(all(Aircycling_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix


Aindex = length(Aircycling_MAV);

avg_MAV_Aircycling = [sum( Aircycling_MAV(1:Aindex, 1) ) / 60 sum( Aircycling_MAV(1:Aindex, 2) ) / 60];



%% Normalized

for i = 1:n
    Aircycling_MAV_Norm(:, i) = (avg_MAV_Aircycling(:,i)./MVC_waist(1, i)).*100;
end




%% Plot Comparison Figure

MAV_Norm = [Aircycling_MAV_Norm; Crunches_MAV_Norm; Lyinglegraises_MAV_Norm; Bentkneesholdabdomen_MAV_Norm];

Movements = categorical( { ' AirCycling ' , ' Crunch ' , ' Lying leg raises ' ,  ' Bent knees hold abdomen '} );
Movements = reordercats(Movements, { ' AirCycling ' , ' Crunch ' , ' Lying leg raises ' ,  ' Bent knees hold abdomen '} );

barh(Movements, MAV_Norm);

xlabel(' EMG activation percentage  (%) ');
ylabel(' Waist Exercises ');
legend(' Right ' , ' Left ');
sgtitle('   Waist EMG Activation of Different Movements ');