%% preallocation of resources
n = 6;                      %number of channels
L = length(time);   %length of data
fs = 200;                %sampling frequency
T = 1 / fs;               %sampling period


%% Normal Part



%% Plot original Normal EMG data

figure;

for t = 1:2
     subplot(2, 1, t);
     plot(time, Normal(:, t));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Normal sitting posture Waist EMG signal ');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(time, Normal(:, t+2));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Normal sitting posture Cervical Vertebra EMG Signal');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(time, Normal(:, t+4));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Latissimus dorsi ');
     else
         title(' Right Latissimus dorsi ');   
     end
end

sgtitle(' Normal sitting posture Latissimus dorsi EMG Signal');
hold off    



 %% RMS calculation of Normal data

window = 50;       % RMS of every 50 sequential data, equivalent as 250ms

for a = 1:n
            for i = 50:window:L
             Normal_RMS(i, a) = sqrt( sum(Normal(i-49:i, a).^2) / window);           % calculate RMS of every  sequential data
            end
end


Normal_RMS(all(Normal_RMS==0, 2), :) = [];   %delete all 0 of RMS matrix



 %% MVC calculation

MVC_Lwaist =  492;
MVC_Rwaist = 486;

MVC_Lneck = 972;
MVC_Rneck = 970;

MVC_Lback = 757;
MVC_Rback = 746;



%% Normalisation of waist EMG (Comparing with MVC)

MVC_waist = [MVC_Lwaist MVC_Rwaist];
MVC_neck = [MVC_Lneck MVC_Rneck];
MVC_back = [MVC_Lback MVC_Rback];

% Divide signal by MVC and convert to percentage

for q = 1:2
    Normal_MVC_normalised(:, q) = (Normal_RMS(:,q)./MVC_waist(1, q)).*100;
    
    Normal_MVC_normalised(:, q+2) = (Normal_RMS(:,q+2)./MVC_neck(1, q)).*100;
    
    Normal_MVC_normalised(:, q+4) = (Normal_RMS(:,q+4)./MVC_back(1, q)).*100;
    
end



%% Plot RMS signal

%calculate sampling time for RMS

Normal_time_window = window * T;
Normal_counter = length(Normal_RMS);
Normal_total_time = Normal_counter * Normal_time_window;

Normal_RMS_time = [];

for r = Normal_time_window : Normal_time_window : Normal_total_time
    Normal_RMS_time = [Normal_RMS_time, r];
end

Normal_RMS_time = reshape(Normal_RMS_time, Normal_counter, 1);


% plot RMS

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_RMS(:, t));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end 
end
    sgtitle(' Normal sitting posture Waist RMS EMG signal ');   
    hold off
    
    
figure;
    
for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_RMS(:, t+2));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Normal sitting posture Cervical Vertebra RMS EMG Signal '); 
hold off


figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_RMS(:, t+4));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Latissimus dorsi ');
     else
         title(' Right Latissimus dorsi ');   
     end
end
     
sgtitle(' Normal sitting posture Latissimus dorsi RMS EMG Signal ');
hold off



%% Plot Normal MVC_normalised value

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');

    grid
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' MVC Normalized percentage of Waist EMG ');
    hold on
    
    
 figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t+2));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');

    grid
    
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
         title(' Right Cervical Vertebra ');
     end  
end
    sgtitle(' MVC Normalized percentage of Cervical Vertebra EMG ');
    hold on
    
    
 figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t+4));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');

    grid
    
     if(t == 1)
         title(' Left Latissimus dorsi ');
     else
         title(' Right Latissimus dorsi ');
     end  
end
    sgtitle(' MVC Normalized percentage of Latissimus dorsi EMG ');
    hold on
    
    
    
    
 %% Hunchbacked
 
 
 %% Plot original abnormal EMG data

figure;

for t = 1:2
     subplot(2, 1, t);
     plot(time, Hunchbacked(:, t));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Hunchbacked sitting posture Waist EMG Signal ');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(time, Hunchbacked(:, t+2));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Hunchbacked sitting posture Cervical Vertebra EMG Signal ');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(time, Hunchbacked(:, t+4));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Right Latissimus dorsi ');
     else
         title(' Left Latissimus dorsi ');   
     end
end

sgtitle(' Hunchbacked sitting posture Latissimus dorsi EMG Signal ');
hold off    



%% RMS calculation of Normal data


for a = 1:n
            for i = 50:window:L
            Hunchbacked_RMS(i, a) = sqrt( sum(Hunchbacked(i-49:i, a).^2) / window);           % calculate RMS
            end
end


Hunchbacked_RMS(all(Hunchbacked_RMS==0, 2), :) = [];   %delete all 0 of RMS matrix



%% Normalisation of waist EMG (Comparing with MVC)

% Divide signal by MVC and convert to percentage

for q = 1:2
    Hunchbacked_MVC_normalised(:, q) = (Hunchbacked_RMS(:,q)./MVC_waist(1, q)).*100;
    
    Hunchbacked_MVC_normalised(:, q+2) = (Hunchbacked_RMS(:,q+2)./MVC_neck(1, q)).*100;
    
    Hunchbacked_MVC_normalised(:, q+4) = (Hunchbacked_RMS(:,q+4)./MVC_back(1, q)).*100;
    
end



%% Plot RMS signal

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Hunchbacked_RMS(:, t));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end 
end
    sgtitle(' Hunchbacked sitting posture Waist RMS EMG signal ');   
    hold off
    
    
figure;
    
for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Hunchbacked_RMS(:, t+2));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Hunchbacked sitting posture Cervical Vertebra RMS EMG Signal '); 
hold off


figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Hunchbacked_RMS(:, t+4));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Latissimus dorsi ');
     else
         title(' Right Latissimus dorsi ');   
     end
end
     
sgtitle(' Hunchbacked sitting posture Latissimus dorsi RMS EMG Signal ');
hold off



%% Plot Hunchbacked MVC_normalised value

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Hunchbacked_MVC_normalised(:, t));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');

    grid
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' MVC Normalized percentage of Hunchbacked Waist EMG ');
    hold on
    
    
 figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Hunchbacked_MVC_normalised(:, t+2));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');

    grid
    
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
         title(' Right Cervical Vertebra ');
     end  
end
    sgtitle(' MVC Normalized percentage of Hunchbacked Cervical Vertebra EMG ');
    hold on
    
    
 figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Hunchbacked_MVC_normalised(:, t+4));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');

    grid
    
     if(t == 1)
         title(' Left Latissimus dorsi ');
     else
         title(' Right Latissimus dorsi ');
     end  
end
    sgtitle(' MVC Normalized percentage of Hunchbacked Latissimus dorsi EMG ');
    hold on
    

%% Comparison of normal and abnormal Normalised EMG signal

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t));
    hold on
    
    plot(Normal_RMS_time, Hunchbacked_MVC_normalised(:, t), 'r', 'linewidth', 2);
    
    legend('Normal' , 'Hunchbacked');
    
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');
    grid
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' MVC Normalized percentage of Waist EMG ');

    
figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t+2));
    hold on
    
    plot(Normal_RMS_time, Hunchbacked_MVC_normalised(:, t+2), 'r', 'linewidth', 2);
    
    legend('Normal' , 'Hunchbacked');
    
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');
    grid
    
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
         title(' Right Cervical Vertebra ');
     end  
end
    sgtitle(' MVC Normalized percentage of Cervical Vertebra EMG ');
    
    
    figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t+4));
    hold on
    
    plot(Normal_RMS_time, Hunchbacked_MVC_normalised(:, t+4), 'r', 'linewidth', 2);
    
    legend('Normal' , 'Hunchbacked');
    
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');
    grid
    
     if(t == 1)
         title(' Left Latissimus dorsi ');
     else
         title(' Right Latissimus dorsi ');
     end  
end
    sgtitle(' MVC Normalized percentage of Latissimus dorsi EMG ');