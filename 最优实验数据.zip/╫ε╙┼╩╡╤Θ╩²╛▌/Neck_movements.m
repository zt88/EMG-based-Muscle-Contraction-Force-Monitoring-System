%% preallocation of resources
n = 2;                      %number of channels
fs = 200;                %sampling frequency
T = 1 / fs;               %sampling period



%% MVC calculation

MVC_Lneck = 972;
MVC_Rneck = 970;

MVC_neck = [MVC_Rneck MVC_Lneck];




%% Movement 1: Neck stretches

NL = length(neckstretches);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Ntime, neckstretches(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Cervical Vertebra ');
     else
         title(' Left Cervical Vertebra ');
     end
end

sgtitle(' "Neck Streches" Cervical Vertebra EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:NL
    neckstretches_MAV(k, i) = sum( neckstretches(k-99:k, i) ) / window;
    end
end

neckstretches_MAV(all(neckstretches_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Nindex = length(neckstretches_MAV);

avg_MAV_neckstretches = [sum( neckstretches_MAV(1:Nindex, 1) ) / 60 sum( neckstretches_MAV(1:Nindex, 2) ) / 60];



%% Normalized

for i = 1:n
    neckstretches_MAV_Norm(:, i) = (avg_MAV_neckstretches(:,i)./MVC_neck(1, i)).*100;
end






%% Movement 2: Head movements

HL = length(headmovements);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Htime, headmovements(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Cervical Vertebra ');
     else
         title(' Left Cervical Vertebra ');
     end
end

sgtitle(' "Head Movemnts" Cervical Vertebra EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:HL
    headmovements_MAV(k, i) = sum( headmovements(k-99:k, i) ) / window;
    end
end

headmovements_MAV(all(headmovements_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Hindex = length(headmovements_MAV);

avg_MAV_headmovements = [sum( headmovements_MAV(1:Hindex, 1) ) / 62 sum( headmovements_MAV(1:Hindex, 2) ) / 62];



%% Normalized

for i = 1:n
    headmovements_MAV_Norm(:, i) = (avg_MAV_headmovements(:,i)./MVC_neck(1, i)).*100;
end






%% Movement 3: Raise shoulders & neck

RL = length( raiseshouldersnecks);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Rtime, raiseshouldersnecks(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Cervical Vertebra ');
     else
         title(' Left Cervical Vertebra ');
     end
end

sgtitle(' "Raise shoulders & neck" Cervical Vertebra EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:RL
    raiseshouldersnecks_MAV(k, i) = sum( raiseshouldersnecks(k-99:k, i) ) / window;
    end
end

raiseshouldersnecks_MAV(all(raiseshouldersnecks_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Rindex = length(raiseshouldersnecks_MAV);

avg_MAV_raiseshouldersnecks = [sum( raiseshouldersnecks_MAV(1:Rindex, 1) ) / 60 sum( raiseshouldersnecks_MAV(1:Rindex, 2) ) / 60];



%% Normalized

for i = 1:n
     raiseshouldersnecks_MAV_Norm(:, i) = (avg_MAV_raiseshouldersnecks(:,i)./MVC_neck(1, i)).*100;
end





%% Plot Comparison Figure

MAV_Norm = [raiseshouldersnecks_MAV_Norm; headmovements_MAV_Norm; neckstretches_MAV_Norm];

Movements = categorical( { ' Raise shoulders & neck ' , ' Head movements ' ,  ' Neck stretches '} );
Movements = reordercats(Movements, { ' Raise shoulders & neck ' , ' Head movements ' , ' Neck stretches '} );

barh(Movements, MAV_Norm);

xlabel(' EMG activation percentage  (%) ');
ylabel(' Cervical Vertebra Exercises ');
legend(' Right ' , ' Left ');
sgtitle('   Cervical Vertebra EMG Activation of Different Movements ');