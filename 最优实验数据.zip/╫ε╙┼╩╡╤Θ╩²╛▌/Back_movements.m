%% preallocation of resources
n = 2;                      %number of channels
fs = 200;                %sampling frequency
T = 1 / fs;               %sampling period


%% MVC calculation

MVC_Lback = 757;
MVC_Rback = 746;

MVC_back = [MVC_Rback MVC_Lback];




%% Movement 1: Kneeling with back stretched

KL = length(kneelingwithbackstretched);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Ktime, kneelingwithbackstretched(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Latissimus dorsi ');
     else
         title(' Left Latissimus dorsi ');
     end
end

sgtitle(' "Kneeling with back stretched" Latissimus dorsi EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:KL
    kneelingwithbackstretched_MAV(k, i) = sum( kneelingwithbackstretched(k-99:k, i) ) / window;
    end
end

kneelingwithbackstretched_MAV(all(kneelingwithbackstretched_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Kindex = length(kneelingwithbackstretched_MAV);

avg_MAV_kneelingwithbackstretched = [sum( kneelingwithbackstretched_MAV(1:Kindex, 1) ) / 55 sum( kneelingwithbackstretched_MAV(1:Kindex, 2) ) / 55];



%% Normalized

for i = 1:n
    kneelingwithbackstretched_MAV_Norm(:, i) = (avg_MAV_kneelingwithbackstretched(:,i)./MVC_back(1, i)).*100;
end




%% Movement 2: Superman
SL = length(superman);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Stime, superman(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Latissimus dorsi ');
     else
         title(' Left Latissimus dorsi ');
     end
end

sgtitle(' "Superman" Latissimus dorsi EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:SL
    superman_MAV(k, i) = sum( superman(k-99:k, i) ) / window;
    end
end

superman_MAV(all(superman_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Sindex = length(superman_MAV);

avg_MAV_superman = [sum( superman_MAV(1:Sindex, 1) ) / 60 sum( superman_MAV(1:Sindex, 2) ) / 60];



%% Normalized

for i = 1:n
    superman_MAV_Norm(:, i) = (avg_MAV_superman(:,i)./MVC_back(1, i)).*100;
end






%% Movement 3: Bend "I" stretch
IL = length(BendIstretch);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Itime, BendIstretch(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Latissimus dorsi ');
     else
         title(' Left Latissimus dorsi ');
     end
end

sgtitle(' "Bend "I" stretch" Latissimus dorsi EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:IL
    BendIstretch_MAV(k, i) = sum( BendIstretch(k-99:k, i) ) / window;
    end
end

BendIstretch_MAV(all(BendIstretch_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Iindex = length(BendIstretch_MAV);

avg_MAV_BendIstretch = [sum( BendIstretch_MAV(1:Iindex, 1) ) / 60 sum( BendIstretch_MAV(1:Iindex, 2) ) / 60];



%% Normalized

for i = 1:n
    BendIstretch_MAV_Norm(:, i) = (avg_MAV_BendIstretch(:,i)./MVC_back(1, i)).*100;
end





%% Movement 4: Bend "T" stretch
TL = length(BentTstretch);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Ttime, BentTstretch(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Right Latissimus dorsi ');
     else
         title(' Left Latissimus dorsi ');
     end
end

sgtitle(' "Bend "T" stretch" Latissimus dorsi EMG signal ');
hold off



%% MAV calculation

window = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:window:TL
    BentTstretch_MAV(k, i) = sum( BentTstretch(k-99:k, i) ) / window;
    end
end

BentTstretch_MAV(all(BentTstretch_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix

Tindex = length(BentTstretch_MAV);

avg_MAV_BentTstretch = [sum( BentTstretch_MAV(1:Tindex, 1) ) / 60 sum( BentTstretch_MAV(1:Tindex, 2) ) / 60];



%% Normalized

for i = 1:n
    BentTstretch_MAV_Norm(:, i) = (avg_MAV_BentTstretch(:,i)./MVC_back(1, i)).*100;
end




%% Plot Comparison Figure

MAV_Norm = [BendIstretch_MAV_Norm; superman_MAV_Norm; BentTstretch_MAV_Norm; kneelingwithbackstretched_MAV_Norm];

Movements = categorical( { ' Bend "I" Stretch ' , ' Superman ' ,  ' Bent "T" Stretch ' , ' Kneeling with Back Stretched ' } );
Movements = reordercats(Movements, { ' Bend "I" Stretch ' , ' Superman ' ,  ' Bent "T" Stretch ' , ' Kneeling with Back Stretched ' } );

barh(Movements, MAV_Norm);

xlabel(' EMG activation percentage  (%) ');
ylabel(' Latissimus dorsi Exercises ');
legend(' Right ' , ' Left ');
sgtitle('   Latissimus dorsi EMG Activation of Different Movements ');