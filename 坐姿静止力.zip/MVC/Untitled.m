Left_L = length(Left);
Right_L = length(Right);

%% MSV Calculation

Left_MSV = sqrt( sum(Left(:, 1) .^2) / Left_L);
Right_MSV = sqrt( sum(Right(:, 1) .^2) / Right_L);