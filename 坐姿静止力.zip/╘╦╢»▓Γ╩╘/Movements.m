%% preallocation of resources
n = 2;                      %number of channels
fs = 200;                %sampling frequency
T = 1 / fs;               %sampling period



%% MVC calculation
Left_L = length(Left);
Right_L = length(Right);

Left_MVC = sqrt( sum(Left(:, 1) .^2) / Left_L);
Right_MVC = sqrt( sum(Right(:, 1) .^2) / Right_L);
MVC = [Left_MVC Right_MVC];




%% Back Bridge movement

BL = length(BackBridge);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Btime, BackBridge(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' "Bent knees leg raises" Waist  EMG signal ');
hold off


%% MAV calculation

Bwindow = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:Bwindow:BL
    BackBridge_MAV(k, i) = sum( BackBridge(k-99:k, i) ) / Bwindow;
    end
end

BackBridge_MAV(all(BackBridge_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix



%% Calculate average MAV during 1s of BackBridge

avg_MAV_BackBridge = [];

for r = 1:n
    avg_MAV_BackBridge = [avg_MAV_BackBridge, (sum( BackBridge_MAV(12:41, r) ) + sum( BackBridge_MAV(52:81,r) ) + sum( BackBridge_MAV(89:118, r) )) / 3 / 15];
end


%% Normalised

for i = 1:n
    BackBridge_MAV_Norm(:, i) = (avg_MAV_BackBridge(:,i)./MVC(1, i)).*100;
end





%% Air-Cycling

AL = length(Atime);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Atime, aircycling(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Air-Cycling Waist  EMG signal ');
hold off


%% MAV calculation

Awindow = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:Awindow:AL
    MAV_AirCycling(k, i) = sum( aircycling(k-99:k, i) ) / Awindow;
    end
end

MAV_AirCycling(all(MAV_AirCycling==0, 2), :) = [];   %delete all 0 of MAV matrix

counter = length(MAV_AirCycling);

avg_MAV_AirCycling = [sum( MAV_AirCycling(1:counter, 1) ) / 22 sum( MAV_AirCycling(1:counter, 2) ) / 22];



%% Normalized

for i = 1:n
    AirCycling_MAV_Norm(:, i) = (avg_MAV_AirCycling(:,i)./MVC(1, i)).*100;
end




%% Lying leg raises

LL = length(Ltime);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Ltime, Legup(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' "Lying leg raises" Waist EMG signal ');
hold off



%% MAV calculation

Lwindow = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:Lwindow:LL
    Legup_MAV(k, i) = sum( Legup(k-99:k, i) ) / Lwindow;
    end
end

Legup_MAV(all(Legup_MAV==0, 2), :) = [];   %delete all 0 of MAV matrix



%% Calculate average MAV during 1s of Legup

avg_MAV_Legup = [];

for r = 1:n
    avg_MAV_Legup = [avg_MAV_Legup, (sum( Legup_MAV(6:34, r) ) + sum( Legup_MAV(39:67,r) ) ) / 2 / 14];
end


%% Normalized

for i = 1:n
    Legup_MAV_Norm(:, i) = (avg_MAV_Legup(:,i)./MVC(1, i)).*100;
end






%% Crunch

CL = length(Crunch);


%% Plot raw signal

figure;

for y = 1:n
     subplot(2, 1, y);
     plot(Ctime, Crunch(:, y));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(y == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Crunch Waist EMG signal ');
hold off



%% MAV calculation

Cwindow = 100;        % MAV of every 100 sequential data, equivalent to 0.5s

for i = 1:n
    for k = 100:Cwindow:CL
    Crunch_MAV(k, i) = sum( Crunch(k-99:k, i) ) / Cwindow;
    end
end

Crunch_MAV(all(Crunch_MAV==0, 2), :) = [];   %delete all 0 in MAV matrix

index = length(Crunch_MAV);

avg_MAV_Crunch = [sum( Crunch_MAV(1:index, 1) ) / 20 sum( Crunch_MAV(1:index, 2) ) / 20];



%% Normalized

for i = 1:n
    Crunch_MAV_Norm(:, i) = (avg_MAV_Crunch(:,i)./MVC(1, i)).*100;
end





%% Plot Comparison Figure

MAV_Norm = [AirCycling_MAV_Norm; Crunch_MAV_Norm; BackBridge_MAV_Norm; Legup_MAV_Norm];

Movements = categorical( { ' AirCycling ' , ' Crunch ' , ' Bent knees leg raises ' , ' Lying leg raises ' } );
Movements = reordercats(Movements, { ' AirCycling ' , ' Crunch ' , ' Bent knees leg raises ' , ' Lying leg raises ' } );

barh(Movements, MAV_Norm);

xlabel(' EMG activation percentage  (%) ');
ylabel(' waist exercises ');
legend(' Left ' , ' Right ');
sgtitle('   Waist EMG Activation of Different Movements ');




