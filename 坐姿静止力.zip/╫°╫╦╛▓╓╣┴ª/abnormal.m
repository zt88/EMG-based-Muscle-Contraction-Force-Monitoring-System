%% preallocation of resources
n = 6;                      %number of channels
L = length(time);   %length of data
fs = 200;                %sampling frequency
T = 1 / fs;               %sampling period


%% Normal Part


%% Plot original Normal EMG data

figure;

for i = 1:2
     subplot(2, 1, i);
     plot(time, Normal(:, i));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(i == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Normal Waist  EMG signal ');
hold off


figure;

for i = 1:2
     subplot(2, 1, i);
     plot(time, Normal(:, i+2));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(i == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Normal Cervical Vertebra EMG Signal');
hold off


figure;

for i = 1:2
     subplot(2, 1, i);
     plot(time, Normal(:, i+4));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(i == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end

sgtitle(' Normal Shoulder-Back EMG Signal');
hold off    
    

 %% RMS calculation of Normal data

window = 50;       % RMS of every 50 sequential data, equivalent as 250ms

for v = 1:n
            for i = 50:window:L
             RMS(i, v) = sqrt( sum(Normal(i-49:i, v).^2) / window);           % calculate RMS
            end
end


RMS(all(RMS==0, 2), :) = [];   %delete all 0 of RMS matrix



 %% MSV calculation
Left_L = length(Left);
Right_L = length(Right);

Left_MVC = sqrt( sum(Left(:, 1) .^2) / Left_L);
Right_MVC = sqrt( sum(Right(:, 1) .^2) / Right_L);



%% Normalisation of waist EMG (Comparing with MVC)

MVC = [Left_MVC Right_MVC];

% Divide signal by MVC and convert to percentage
for i = 1:2
    MVC_normalised(:, i) = (RMS(:,i)./MVC(1, i)).*100;
end



%% Plot RMS signal

%calculate sampling time for RMS

time_window = window * T;
counter = length(RMS);
total_time = counter * time_window;

RMS_time = [];

for i = time_window : time_window : total_time
    RMS_time = [RMS_time, i];
end

RMS_time = reshape(RMS_time, counter, 1);


% plot RMS

figure;

for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, RMS(:, i));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(i == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end 
end
    sgtitle(' Waist RMS EMG signal ');   
    hold off
    
    
figure;
    
for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, RMS(:, i+2));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(i == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Cervical Vertebra RMS EMG Signal '); 
hold off


figure;

for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, RMS(:, i+4));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(i == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end
     
sgtitle(' Shoulder-Back RMS EMG Signal ');
hold off



%% Plot MVC_normalised value

figure;

for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, MVC_normalised(:, i));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');
    title(' MVC  Normalised ');
    grid
    
     if(i == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' MVC Normalized EMG signal percentage of Waist ');
    hold on
    
    
    
    
    
%%   Abnormal Part


%% Plot original abnormal EMG data

figure;

for i = 1:2
     subplot(2, 1, i);
     plot(abnormal_time, abnormal(:, i));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(i == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Waist Raw EMG Signal ');
hold off


figure;

for i = 1:2
     subplot(2, 1, i);
     plot(abnormal_time, abnormal(:, i+2));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(i == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle('Cervical Vertebra Raw sEMG Signal');
hold off


figure;

for i = 1:2
     subplot(2, 1, i);
     plot(abnormal_time, abnormal(:, i+4));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(i == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end

sgtitle('Shoulder-Back Raw sEMG Signal');
hold off    
    

 %% RMS calculation of Normal data

window = 50;       % RMS of every 50 sequential data, equivalent as 250ms

for v = 1:n
            for i = 50:window:L
             RMS(i, v) = sqrt( sum(abnormal(i-49:i, v).^2) / window);           % calculate RMS
            end
end


RMS(all(RMS==0, 2), :) = [];   %delete all 0 of RMS matrix



 %% MVC calculation
Left_L = length(Left);
Right_L = length(Right);

Left_MVC = sqrt( sum(Left(:, 1) .^2) / Left_L);
Right_MVC = sqrt( sum(Right(:, 1) .^2) / Right_L);



%% Normalisation of waist EMG (Comparing with MVC)

MVC = [Left_MVC Right_MVC];

% Divide signal by MVC and convert to percentage
for i = 1:2
    MVC_normalised(:, i) = (RMS(:,i)./MVC(1, i)).*100;
end



%% Plot RMS signal

%calculate sampling time for RMS

time_window = window * T;
counter = length(RMS);
total_time = counter * time_window;

RMS_time = [];

for i = time_window : time_window : total_time
    RMS_time = [RMS_time, i];
end

RMS_time = reshape(RMS_time, counter, 1);


% plot RMS

figure;

for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, RMS(:, i));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(i == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end 
end
    sgtitle(' Waist RMS EMG signal ');   
    hold off
    
    
figure;
    
for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, RMS(:, i+2));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(i == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Cervical Vertebra RMS EMG Signal '); 
hold off


figure;

for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, RMS(:, i+4));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(i == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end
     
sgtitle(' Shoulder-Back RMS EMG Signal ');
hold off



%% Plot MVC_normalised value

figure;

for i=1:2
    subplot(2, 1, i)
    plot(RMS_time, MVC_normalised(:, i));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');
    title(' MVC  Normalised ');
    grid
    
     if(i == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' MVC Normalized EMG signal percentage of Waist ');
    hold on