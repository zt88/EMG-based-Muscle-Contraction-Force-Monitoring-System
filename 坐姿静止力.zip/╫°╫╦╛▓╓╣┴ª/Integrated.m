%% preallocation of resources
n = 6;                      %number of channels
L = length(Normal_time);   %length of data
fs = 200;                %sampling frequency
T = 1 / fs;               %sampling period


%% Normal Part


%% Plot original Normal EMG data

figure;

for t = 1:2
     subplot(2, 1, t);
     plot(Normal_time, Normal(:, t));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Normal Waist  EMG signal ');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(Normal_time, Normal(:, t+2));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Normal Cervical Vertebra EMG Signal');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(Normal_time, Normal(:, t+4));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end

sgtitle(' Normal Shoulder-Back EMG Signal');
hold off    
    

 %% RMS calculation of Normal data

Normal_window = 50;       % RMS of every 50 sequential data, equivalent as 250ms

for a = 1:n
            for t = 50:window:L
             Normal_RMS(t, a) = sqrt( sum(Normal(t-49:t, a).^2) / Normal_window);           % calculate RMS
            end
end


Normal_RMS(all(Normal_RMS==0, 2), :) = [];   %delete all 0 of RMS matrix



 %% MVC calculation
Left_L = length(Left);
Right_L = length(Right);

Left_MVC = sqrt( sum(Left(:, 1) .^2) / Left_L);
Right_MVC = sqrt( sum(Right(:, 1) .^2) / Right_L);



%% Normalisation of waist EMG (Comparing with MVC)

MVC = [Left_MVC Right_MVC];

% Divide signal by MVC and convert to percentage
for t = 1:2
    Normal_MVC_normalised(:, t) = (Normal_RMS(:,t)./MVC(1, t)).*100;
end



%% Plot RMS signal

%calculate sampling time for RMS

Normal_time_window = window * T;
Normal_counter = length(Normal_RMS);
Normal_total_time = Normal_counter * Normal_time_window;

Normal_RMS_time = [];

for t = Normal_time_window : Normal_time_window : Normal_total_time
    Normal_RMS_time = [Normal_RMS_time, t];
end

Normal_RMS_time = reshape(Normal_RMS_time, Normal_counter, 1);


% plot RMS

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_RMS(:, t));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end 
end
    sgtitle(' Normal Waist RMS EMG signal ');   
    hold off
    
    
figure;
    
for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_RMS(:, t+2));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Cervical Vertebra RMS EMG Signal (normal) '); 
hold off


figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_RMS(:, t+4));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end
     
sgtitle(' Shoulder-Back RMS EMG Signal (normal) ');
hold off



%% Plot Normal MVC_normalised value

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');

    grid
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' MVC Normalized percentage of Waist (normal) ');
    hold on
    
    
    
    
    
    
    
    
%%   Abnormal Part

AL = length(abnormal_time);

%% Plot original abnormal EMG data

figure;

for t = 1:2
     subplot(2, 1, t);
     plot(abnormal_time, abnormal(:, t));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end
end

sgtitle(' Hunchbacked Waist Raw EMG Signal ');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(abnormal_time, abnormal(:, t+2));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle('Abnormal Cervical Vertebra Raw sEMG Signal');
hold off


figure;

for t = 1:2
     subplot(2, 1, t);
     plot(abnormal_time, abnormal(:, t+4));
     xlabel(' Time  (s) ');
     ylabel(' Voltage  (mV) ');
     
     grid
     hold on
     
     if(t == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end

sgtitle('Abnormal Shoulder-Back Raw sEMG Signal');
hold off    
    

 %% RMS calculation of Normal data

window = 50;       % RMS of every 50 sequential data, equivalent as 250ms

for v = 1:n
            for t = 50:window:AL
             RMS(t, v) = sqrt( sum(abnormal(t-49:t, v).^2) / window);           % calculate RMS
            end
end


RMS(all(RMS==0, 2), :) = [];   %delete all 0 of RMS matrix



%% Normalisation of abnormal waist EMG (Comparing with MVC)

MVC = [Left_MVC Right_MVC];

% Divide signal by MVC and convert to percentage
for t = 1:2
    MVC_normalised(:, t) = (RMS(:,t)./MVC(1, t)).*100;
end



%% Plot RMS signal

%calculate sampling time for RMS

time_window = window * T;
counter = length(RMS);
total_time = counter * time_window;

RMS_time = [];

for t = time_window : time_window : total_time
    RMS_time = [RMS_time, t];
end

RMS_time = reshape(RMS_time, counter, 1);


% plot RMS

figure;

for t=1:2
    subplot(2, 1, t)
    plot(RMS_time, RMS(:, t));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end 
end
    sgtitle(' Hunchbacked Waist RMS EMG signal ');   
    hold off
    
    
figure;
    
for t=1:2
    subplot(2, 1, t)
    plot(RMS_time, RMS(:, t+2));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Left Cervical Vertebra ');
     else
          title(' Right Cervical Vertebra ');    
     end
end

sgtitle(' Cervical Vertebra RMS EMG Signal '); 
hold off


figure;

for t=1:2
    subplot(2, 1, t)
    plot(RMS_time, RMS(:, t+4));
    
    xlabel(' Time  (s) ');
    ylabel(' Voltage  (mV) ');
    
    grid
    hold on
    
     if(t == 1)
         title(' Right Shoulder-Back ');
     else
         title(' Left Shoulderb-Back ');   
     end
end
     
sgtitle(' Shoulder-Back RMS EMG Signal ');
hold off



%% Plot MVC_normalised value

figure;

for t=1:2
    subplot(2, 1, t)
    plot(RMS_time, MVC_normalised(:, t));
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');
    title(' MVC  Normalised ');
    grid
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' Hunchbacked MVC Normalized  percentage of Waist ');
    hold on
    

    
    
    
    
%% Comparison of normal and abnormal Normalised EMG signal

figure;

for t=1:2
    subplot(2, 1, t)
    plot(Normal_RMS_time, Normal_MVC_normalised(:, t));
    hold on
    
    plot(RMS_time, MVC_normalised(:, t), 'r', 'linewidth', 2);
    
    legend('Normal' , 'Hunchbacked');
    
    xlabel(' Time  (s) ');
    ylabel(' MVC Normalised  (%) ');
    grid
    
     if(t == 1)
         title(' Left Waist ');
     else
         title(' Right Waist ');
     end  
end
    sgtitle(' MVC Normalized EMG signal percentage of Waist ');


    